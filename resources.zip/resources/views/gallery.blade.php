@extends('layouts.main')

@section('content')
<section class="gallery">
    <h2>Galeri Proyek Interior Kami</h2>

    <p>Berikut adalah beberapa hasil karya desain interior terbaik kami yang telah kami kerjakan untuk klien-klien di berbagai sektor seperti rumah tinggal, perkantoran, hingga komersial.</p>

    <div class="gallery-grid">
        <div class="gallery-item">
            <img src="{{ asset('images/galeri1.jpg') }}" alt="Desain Meja Makan">
            <p>Desain meja makan</p>
        </div>
        <div class="gallery-item">
            <img src="{{ asset('images/galeri5.jpg') }}" alt="Interior Kantor Elegan">
            <p>Interior kantor dengan konsep terbuka dan elegan</p>
        </div>
        <div class="gallery-item">
            <img src="{{ asset('images/galeri4.jpg') }}" alt="Kamar Tidur Nyaman">
            <p>Kamar tidur dengan pencahayaan alami dan nuansa hangat</p>
        </div>
        <div class="gallery-item">
            <img src="{{ asset('images/galeri6.jpg') }}" alt="Dapur Mewah">
            <p>Dapur mewah dengan kombinasi warna netral dan pencahayaan LED</p>
        </div>
    </div>
</section>
@endsection
