@extends('layouts.main')

@section('content')
<section class="hero">
    <h1>Selamat Datang di Profil Perusahaan Interior Design</h1>
    <p>Kami memberikan solusi desain interior terbaik untuk rumah dan ruang kerja Anda.</p>
</section>

<section class="services">
    <h2>Layanan Kami</h2>
    <div class="service-list">
        <!-- Contoh data layanan statis -->
        <div class="service-card">
            <h3>Desain Ruang Tamu</h3>
            <p>Desain elegan dan nyaman untuk ruang tamu Anda.</p>
        </div>
        <div class="service-card">
            <h3>Dekorasi Kantor</h3>
            <p>Atur ulang kantor Anda agar lebih modern dan produktif.</p>
        </div>
    </div>
</section>
@endsection
