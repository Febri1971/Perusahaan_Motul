<nav>
    <ul>
        <li><a href="{{ url('/') }}">Beranda</a></li>
        <li><a href="{{ url('/profile') }}">Profil</a></li>
        <li><a href="{{ url('/services') }}">Layanan</a></li>
        <li><a href="{{ url('/gallery') }}">Galeri</a></li>
        <li><a href="{{ url('/contact') }}">Kontak</a></li>
    </ul>
</nav>
