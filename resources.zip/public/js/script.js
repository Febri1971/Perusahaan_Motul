// script.js
console.log("Script berjalan dengan baik!");
