

<?php $__env->startSection('content'); ?>
<section class="contact">
    <h2>Hubungi Kami</h2>
    <p>Silakan hubungi kami melalui formulir di bawah ini untuk pertanyaan, kerja sama, atau konsultasi desain interior.</p>

    <?php if(session('success')): ?>
        <div style="color: green;"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="contact-wrapper">
        <!-- Form Kontak -->
        <div class="contact-form">
            <form action="<?php echo e(route('contact.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" placeholder="Nama Anda" required>
                <input type="email" name="email" placeholder="Email Anda" required>
                <textarea name="message" rows="5" placeholder="Pesan Anda" required></textarea>
                <button type="submit">Kirim Pesan</button>
            </form>
        </div>

        <!-- Info Kontak -->
        <div class="contact-info">
            <h3>Informasi Kontak</h3>
            <p><strong>Alamat:</strong><br> Jl. Interior Mewah No. 88, Purwokerto</p>
            <p><strong>Email:</strong><br> Dhamar Bagus Ketawang@gmail.com</p>
            <p><strong>Telepon:</strong><br> +62 812 3456 7890</p>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\interior-profile\resources\views/contact.blade.php ENDPATH**/ ?>