<nav>
    <ul>
        <li><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
        <li><a href="<?php echo e(url('/profile')); ?>">Profil</a></li>
        <li><a href="<?php echo e(url('/services')); ?>">Layanan</a></li>
        <li><a href="<?php echo e(url('/gallery')); ?>">Galeri</a></li>
        <li><a href="<?php echo e(url('/contact')); ?>">Kontak</a></li>
    </ul>
</nav>
<?php /**PATH C:\xampp\interior-profile\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>