

<?php $__env->startSection('content'); ?>
<section class="services">
    <h2>Layanan Kami</h2>

    <p>Kami menyediakan berbagai layanan desain interior yang dirancang untuk memenuhi kebutuhan estetika dan fungsionalitas ruangan Anda. Dengan pengalaman lebih dari 8 tahun, kami percaya bahwa setiap ruang memiliki potensi untuk menjadi tempat yang nyaman dan inspiratif.</p>

    <ul>
        <li>
            <h3>1. Desain Interior Rumah Tinggal</h3>
            <p>Kami membantu mewujudkan rumah impian Anda dengan desain yang modern, elegan, dan sesuai dengan gaya hidup Anda.</p>
        </li>

        <li>
            <h3>2. Desain Kantor dan Komersial</h3>
            <p>Ruang kerja dan bisnis yang kami desain mampu menciptakan suasana produktif, profesional, dan mencerminkan identitas brand Anda.</p>
        </li>

        <li>
            <h3>3. Renovasi dan Re-desain</h3>
            <p>Kami memberikan solusi kreatif untuk memperbarui tampilan ruangan lama Anda tanpa harus membangun dari awal.</p>
        </li>

        <li>
            <h3>4. Custom Furniture</h3>
            <p>Pembuatan furnitur sesuai kebutuhan dan ukuran ruangan, dengan desain unik dan material berkualitas tinggi.</p>
        </li>

        <li>
            <h3>5. Konsultasi Desain</h3>
            <p>Kami juga menyediakan layanan konsultasi desain interior bagi Anda yang ingin mendapat arahan profesional sebelum memulai proyek.</p>
        </li>
    </ul>

    <p>Setiap layanan kami ditangani oleh tim ahli yang berdedikasi dan menggunakan pendekatan personal terhadap setiap klien. Hubungi kami untuk mendapatkan solusi interior terbaik sesuai visi Anda.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\interior-profile\resources\views/services.blade.php ENDPATH**/ ?>