<footer>
    <p>&copy; 2025 Dhamar Bagus Ketawang.STI202202830</p>
</footer>
<?php /**PATH C:\xampp\htdocs\interior-profile\resources\views/layouts/footer.blade.php ENDPATH**/ ?>