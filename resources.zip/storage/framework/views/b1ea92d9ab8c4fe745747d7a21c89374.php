

<?php $__env->startSection('content'); ?>
<section class="profile" style="padding: 40px 20px; max-width: 1000px; margin: auto;">
    <h2 style="text-align: center; font-size: 2.5rem; color: #333; margin-bottom: 20px;">Profil Perusahaan</h2>

    <div style="text-align: center; margin-bottom: 30px;">
        <p style="font-size: 1.1rem; color: #555;">
            <strong>Interior Design Studio</strong> adalah perusahaan jasa desain interior yang berdiri sejak tahun 2015
            dan telah menangani berbagai proyek perumahan, komersial, dan institusi di seluruh Indonesia.
        </p>
        <p style="font-size: 1.1rem; color: #555;">
            Kami mengutamakan perpaduan antara estetika, fungsionalitas, dan kenyamanan dalam setiap desain.
            Dengan tim desainer berpengalaman dan tenaga ahli konstruksi, kami memberikan layanan terbaik yang
            disesuaikan dengan kebutuhan dan keinginan klien.
        </p>
    </div>

    <div style="background: #f9f9f9; padding: 25px; border-radius: 10px; margin-bottom: 30px;">
        <h3 style="color: #007BFF; margin-bottom: 15px;">Layanan Unggulan Kami</h3>
        <ul style="list-style: none; padding-left: 0; font-size: 1.05rem; color: #444;">
            <li style="margin-bottom: 10px;">✔️ Desain interior rumah tinggal dan apartemen</li>
            <li style="margin-bottom: 10px;">✔️ Penataan ruang kantor dan ruang publik</li>
            <li style="margin-bottom: 10px;">✔️ Renovasi dan redekorasi interior</li>
            <li style="margin-bottom: 10px;">✔️ Pembuatan custom furniture</li>
        </ul>
    </div>

    <p style="font-size: 1.1rem; color: #555; text-align: center;">
        Komitmen kami adalah mewujudkan ruang impian Anda dengan desain yang tidak hanya indah secara visual,
        tetapi juga nyaman dan fungsional untuk digunakan sehari-hari.
    </p>

    <div style="text-align: center; margin-top: 30px;">
        <img src="<?php echo e(asset('images/galeri0.jpg')); ?>" alt="Desain Interior Kami"
             style="width: 100%; max-width: 700px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\interior-profile\resources\views/profile.blade.php ENDPATH**/ ?>